package com.oracle.determinations.demo;

import com.oracle.determinations.engine.*;

/**
 * This class demonstrates use of the OPA determinations engine Java API
 */
public class EngineAPIDemo {

    /**
     * Main method
     * @param args One command line argument is expected - the file path for the compiled "Loan Advisor" sample rulebase
     */
    public static void main(String[] args) throws Exception {

        if (args.length == 0) {
            System.out.println("Usage: provide the file path for the \"Loan Advisor\" sample rulebase");
            return;
        }

        //Load rulebase - command line argument contains file path for compile "Loan Advisor" sample rulebase
        Rulebase rulebase = Rulebase.getRulebase(args[0]);

        // Create a new rulebase session
        Session session = new Session(rulebase);

        // Every OPA session has a single instance of an entity named global
        EntityInstance globalEntityInstance = session.getGlobalEntityInstance();
        Entity globalEntity = globalEntityInstance.getEntity();

        // Get attributes and entities using their public names
        Attribute customerEligibleLoan = globalEntity.getAttribute("goal_eligible"); // *** This is the GOAL attibute

        Attribute loanPurchasePrice = globalEntity.getAttribute("loan_purchase_price");
        Attribute loanDownPayment = globalEntity.getAttribute("loan_down_payment");
        Attribute loanInterestRate = globalEntity.getAttribute("loan_interest_rate");

        Attribute customerAge = globalEntity.getAttribute("customer_age");
        Attribute customerEmployed = globalEntity.getAttribute("customer_employed");
        Attribute customerResident = globalEntity.getAttribute("customer_resident");
        Attribute customerPreviousDefaultCreditCard = globalEntity.getAttribute("customer_previous_default_creditcard");
        Attribute customerPreviousDefaultLoan = globalEntity.getAttribute("customer_previous_default_loan");
        Attribute customerBankrupt = globalEntity.getAttribute("customer_bankrupt");

        Entity assetEntity = rulebase.getEntity("asset");
        Attribute assetName = assetEntity.getAttribute("asset_name");
        Attribute assetType = assetEntity.getAttribute("asset_type");
        Attribute assetValue = assetEntity.getAttribute("asset_value");

        Entity incomeSourceEntity = rulebase.getEntity("income_source");
        Attribute incomeSourceName = incomeSourceEntity.getAttribute("income_source_name");
        Attribute incomeSourceAmount = incomeSourceEntity.getAttribute("income_source_amount");
        Attribute incomeSourceFrequency = incomeSourceEntity.getAttribute("income_source_frequency");

        Entity liabilityEntity = rulebase.getEntity("liability");
        Attribute liabilityName = liabilityEntity.getAttribute("liability_name");
        Attribute liabilityType = liabilityEntity.getAttribute("liability_type");
        Attribute liabilityValue = liabilityEntity.getAttribute("liability_value");

        loanPurchasePrice.setValue(globalEntityInstance, 500000);
        loanDownPayment.setValue(globalEntityInstance, 200000);
        loanInterestRate.setValue(globalEntityInstance, 5);

        customerAge.setValue(globalEntityInstance, 32);
        customerEmployed.setValue(globalEntityInstance, true);
        customerResident.setValue(globalEntityInstance, true);
        customerPreviousDefaultCreditCard.setValue(globalEntityInstance, false);
        customerPreviousDefaultLoan.setValue(globalEntityInstance, false);
        customerBankrupt.setValue(globalEntityInstance, false);

        // Create an instance of the "asset" entity and set its values
        EntityInstance assetInstance = session.createEntityInstance(assetEntity, globalEntityInstance);
        assetName.setValue(assetInstance, "Share Portfolio");
        assetType.setValue(assetInstance, "Stocks");
        assetValue.setValue(assetInstance, 100000);
        // Marking this entity's containment as complete tells the engine that we are done creating instances of this entity
        globalEntityInstance.markContainmentComplete(true, assetEntity);

        // Create an instance of the "income_source" entity and set its values
        EntityInstance incomeSourceInstance = session.createEntityInstance(incomeSourceEntity, globalEntityInstance);
        incomeSourceName.setValue(incomeSourceInstance, "Salary");
        incomeSourceAmount.setValue(incomeSourceInstance, 7000);
        incomeSourceFrequency.setValue(incomeSourceInstance, "per month");
        // Marking this entity's containment as complete tells the engine that we are done creating instances of this entity
        globalEntityInstance.markContainmentComplete(true, incomeSourceEntity);

        // Create an instance of the "liability" entity and set its values
        EntityInstance liabilityInstance = session.createEntityInstance(liabilityEntity, globalEntityInstance);
        liabilityName.setValue(liabilityInstance, "Ford");
        liabilityType.setValue(liabilityInstance, "Car Loan");
        liabilityValue.setValue(liabilityInstance, 20000);
        // Marking this entity's containment as complete tells the engine that we are done creating instances of this entity
        globalEntityInstance.markContainmentComplete(true, liabilityEntity);

        // Calling think gets the engine to process all the data we have input
        session.think();

        // We can now check the value of the goal attribute
        boolean customerEligible = (Boolean) customerEligibleLoan.getValue(globalEntityInstance);
        System.out.println("Customer is eligible for a loan: " + customerEligible);

        // Get decision report
        DecisionReportNode decisionReport = customerEligibleLoan.getDecisionReport(globalEntityInstance);

        // Output contents of decision report
        writeDecisionReportNode(decisionReport, 0);
    }

    /**
     * @return the total number of nodes in the decision report
     */
    private static int writeDecisionReportNode(DecisionReportNode dr, int depth) {
        int runningTotal = 1;
        String attrName = dr.getAttribute() != null ? dr.getAttribute()
                .getName() : null;

        for (int i = 0; i < depth; i++) {
            System.out.print("  ");
        }

        if (attrName != null) {
            System.out.print("Attr: Entity ["
                    + dr.getEntityInstance().getName() + "].["
                    + dr.getAttribute().getName() + ']' + " ("
                    + dr.getAttribute().getValue(dr.getEntityInstance())
                    + ") \"" + dr.getAttributeText() + "\" ");
        }
        if (dr.getRelationship() != null) {
            System.out.print("Rel: " + dr.getRelationship().getName()
                    + " from [" + dr.getEntityInstance().getName()
                    + "] to ["
                    + dr.getRelationship().getTargetEntity().getName()
                    + "] ");
        }
        System.out.println();

        for (DecisionReportNode n : dr.getChildren()) {
            runningTotal += writeDecisionReportNode(n, depth + 1);
        }
        return runningTotal;
    }

}
